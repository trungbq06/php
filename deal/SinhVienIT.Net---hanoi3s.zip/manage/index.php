<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

need_manager();
require_once( 'misc/index.php' );
