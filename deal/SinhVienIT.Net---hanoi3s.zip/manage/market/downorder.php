<?php
require_once(dirname(dirname(dirname(__FILE__))) . '/app.php');

need_manager();
need_auth('market');

if ( $_POST ) {
	$condition = array();
	$team_id = abs(intval($_POST['team_id']));
	$service = $_POST['service'];
	$state = $_POST['state'];
	$cbday = strval($_POST['timeorder']);
$ceday = strval($_GET['ceday']);
$pbday = strval($_GET['pbday']);
$peday = strval($_GET['peday']);
if ($cbday) { 
	$cbtime = strtotime($cbday);
	$condition[] = "create_time >= '{$cbtime}'";
}
if ($ceday) { 
	$cetime = strtotime($ceday);
	$condition[] = "create_time <= '{$cetime}'";
}
if ($pbday) { 
	$pbtime = strtotime($pbday);
	$condition[] = "pay_time >= '{$pbtime}'";
}
if ($peday) { 
	$petime = strtotime($peday);
	$condition[] = "pay_time <= '{$petime}'";
}
	
//	if (!$team_id || !$service || !$state) die('Không tìm thấy dữ liệu nào! <br/>Vui lòng thử lại.<br/><br/>Developed by ThietKeTrangChu<sup>&reg</sup>');
	
	if($team_id){
	$condition[] = "team_id = '{$team_id}'";
	}		
	$orders = DB::LimitQuery('order', array(
				'condition' => $condition,
				'order' => 'ORDER BY pay_time DESC, id DESC',
				));

	if (!$orders) die('Không tìm thấy đơn hàng nào thỏa điều kiện:<br/> - Deal ID:'.$team_id.' <br/> - Thời gian: '.$cbday.'<br/>Vui lòng thử lại.<br/><br/>Developed by ThietKeTrangChu<sup>&reg</sup>');
	$team = Table::Fetch('team', $team_id);
	$name = 'donhang_'.date('d-m-Y');
	$kn = array(
			'id' => 'Số ĐH',
			'pay_id' => 'Mã ĐH',
			'title' => 'Tên deal',	
		//	'service' => 'payment gateway',
			'price' => 'Giá gốc',
			'money' => 'Giá bán',
			'quantity' => 'Số lượng',
		//	'condbuy' => 'option',
		//	'fare' => 'fare',
			'origin' => 'Thành tiền',
			'time_order' => 'Đặt hàng lúc',
		//	'credit' => 'pay with balance',
			'state' => 'Trạng thái',
		
		//	'express' => 'express',
			'username' => 'Họ tên',
			'useremail' => 'Email',
			'address'   => 'Địa chỉ',
			'usermobile' => 'Điện thoại',
			'remark' => 'Ghi chú',	
			);

	if ( $team['delivery'] == 'express' ) {
		$kn = array_merge($kn, array(
					'realname' => 'receiver',
					'mobile' => 'mobile',
					'zipcode' => 'zipcode',
					'address' => 'address',
					));
	}
	$pay = array(
			'alipay' => 'alipay',
			'tenpay' => 'TenPay',
			'chinabank' => 'ChinaBank',
			'credit' => 'Credit',
			'cash' => 'pay in cash',
			'' => 'other',
			);
	$state = array(
			'unpay' => 'to be paid',
			'pay' => 'paid',
			);
	$eorders = array();

	$expresses = option_category('express');
	$users = Table::Fetch('user', Utility::GetColumn($orders, 'user_id'));

	foreach( $orders AS $one ) {
		$oneuser = $users[$one['user_id']];
		$team  = Table::Fetch('team',$one['team_id']);
		$order2  = Table::Fetch('order',$one['id']);
		$tp=explode("-",$order2['zipcode']);
		$city = Table::Fetch('ward-dist',$tp[0]);
		$ward = Table::Fetch('ward-dist',$tp[1]);
		$one['title'] = $team['id'].".".$team['product'];
		$one['money'] =  $team['team_price'];
		$one['time_order'] = date('H:i d-m-Y', $order2['create_time']);
		$one['username'] = $order2['realname']." (".$oneuser['gender'].")";
		$one['useremail'] = $oneuser['email'];
		$one['usermobile'] = $order2['mobile'];
		$one['address'] = $order2['address'].", ".$ward['name'].", ".$city['name'];
		$one['fare'] = ($one['delivery'] == 'express') ? $one['fare'] : 0;
		$one['service'] = $pay[$one['service']];
		$one['price'] = $team['market_price'];
		$one['state'] = $order2['state']=='unpay'?'Chưa xác nhận':'Đã xác nhận';
		$one['express'] = ($one['express_id'] && $one['express_no']) ? 
			$expresses[$one['express_id']] . ":" . $one['express_no']
			: "";
		$eorders[] = $one;
	}
	down_xls($eorders, $kn, $name);
}

include template('manage_market_downorder');
