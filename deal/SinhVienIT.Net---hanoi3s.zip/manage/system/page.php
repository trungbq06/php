<?php
require_once(dirname(dirname(dirname(__FILE__))) . '/app.php');

need_manager();
need_manager('admin');

$pages = array(
	'help_tour' => 'Hướng dẫn mua hàng',
	'help_faqs' => 'Hỏi đáp',
	'help_babydeal' => 'Deal là gì?',
	'help_api' => 'API',
	'about_contact' => 'Liên hệ',
	'about_us' => 'Về chúng tôi',
	'content_seller' => 'Hợp tác kinh doanh',
	'content_news' => 'Tin tức',
	'about_job' => 'Cộng tác viên',
	'content_pay' => 'Thanh toán trực tiếp',
	'content_bank' => 'Thanh toán chuyển khoản',
	'content_money' => 'Quy định hoàn tiền',
	'about_terms' => 'Điều khoản',
	'about_privacy' => 'Privacy',
);

$id = strval($_GET['id']);
if ( $id && !in_array($id, array_keys($pages))) { 
	redirect( WEB_ROOT . "/manage/system/page.php");
}
$n = Table::Fetch('page', $id);

if ( $_POST ) {
	$table = new Table('page', $_POST);
	$table->SetStrip('value');
	if ( $n ) {
		$table->SetPk('id', $id);
		$table->update( array('id', 'value') );
	} else {
		$table->insert( array('id', 'value') );
	}
	Session::Set('notice', "Page：{$pages[$id]}Edited Successfully");
	redirect( WEB_ROOT . "/manage/system/page.php?id={$id}");
}

$value = $n['value'];
include template('manage_system_page');
