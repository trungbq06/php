<?php
function current_manageteam($selector='edit', $id=0) {
	$selector = $selector ? $selector : 'edit';
	$a = array(
		"/manage/team/edit.php?id={$id}" => 'Thông tin cơ bản',
	//	"/manage/team/editzz.php?id={$id}" => 'Miscellaneous Information',
		"/manage/team/editseo.php?id={$id}" => 'Thông tin SEO',
	);
	$l = "/manage/team/{$selector}.php?id={$id}";
	return current_link($l, $a);
}
