<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

$page = Table::Fetch('page', 'about_terms');
$pagetitle = 'User terms';
include template('about_terms');
