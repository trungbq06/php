<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

cookieset('newbie', 'N');
Output::Json(0);
