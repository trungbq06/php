<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

need_login();
$id = abs(intval($_GET['id']));
$action = strval($_GET['action']);

if ( $action == 'exchange') {
	$goods = Table::Fetch('goods', $id);
	if ( $goods['consume'] >= $goods['number'] ) {
		json('Đã hết hàng để đổi', 'alert');
	}
	if ( $goods['score'] > $login_user['score'] ) {
		json('Bạn không đủ điểm để đổi，vui lòng nạp thêm hoặc giới thiệu bạn bè để có điểm thưởng', 'alert');
	}
	if ( ZCredit::Create((0-$goods['score']), $login_user_id, 'exchange', $id) ) {

		Table::UpdateCache('goods', $id, array(
					'consume' => array( '`consume` + 1' ),
					));
		$v = "Đã đổi điểm mua: {$goods['title']} thành công，số điểm bị trừ là: {$goods['score']}";
		json( array(
					array( 'data' => $v, 'type' => 'alert'),
					array( 'data' => null,  'type' => 'refresh'),
				   ), 
				'mix');
	}
	json('exchange failed', 'alert');
}
