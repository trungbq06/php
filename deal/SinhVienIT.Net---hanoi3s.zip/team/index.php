<?php

require_once(dirname(dirname(__FILE__)) . '/app.php');

$daytime = strtotime(date('Y-m-d H:i:s'));
$condition = array(
	'team_type' => 'normal',
	'city_id' => array(0, abs(intval($city['id']))),
	"begin_time <= '{$daytime}'",
);

// if (!option_yes('displayfailure')) {
	// $condition['OR'] = array(
		// "now_number >= min_number",
		// "end_time > '{$daytime}'",
	// );
// }

$group_id = abs(intval($_GET['gid']));
if ($group_id) $condition['group_id'] = $group_id;
$count = Table::Count('team', $condition);
list($pagesize, $offset, $pagestring) = pagestring($count, 10);
$teams = DB::LimitQuery('team', array(
	'condition' => $condition,
	'order' => 'ORDER BY begin_time DESC, sort_order DESC, id DESC',
	'size' => $pagesize,
	'offset' => $offset,
));

/* Dem tong cong tat ca san pham Deal*/
$sp_city = array(
	'city_id' => array(0, abs(intval($city['id']))),
);
$sp_all = Table::Count('team', $sp_city);


/* Them vao */
$left = array();
$now = time();
$diff_time = array();


foreach($teams AS $id=>$team){
	team_state($team);
	if ($team['close_time']) $team['picclass'] = '<font color="red"><b>Đã hết hạn mua</b></font>';
	if (!$team['state']=='soldout') $team['picclass'] = 'soldout';
	if($team['end_time']<$team['begin_time']){$team['end_time']=$team['begin_time'];}
$diff_time = $left_time = $team['end_time']-$now;
if ( $team['team_type'] == 'seconds' && $team['begin_time'] >= $now ) {
	$diff_time = $left_time = $team['begin_time']-$now;
}
	$team['diff_time']=$diff_time;
	$team['left_time']=$left_time;
	

	$team['url']=$INI['system']['wwwprefix']."/".ThietKeTrangChu_SEO($city['name'])."/".ThietKeTrangChu_SEO($team['product'])."-".$team['id'].".html";
	$bix = DB::LimitQuery('partner', array(
		'condition' => array(
			'id' => $team['partner_id'],
		),
		'one' => true,
	));
	$partner['title']=$bix['title'];
	$partner['image']=$bix['image'];
	$partner['other']=$bix['other'];
	$teams[$id] = $team;


}

$category = Table::Fetch('category', $group_id);

if($group_id)
$pagetitle = $category['name'];
else
$pagetitle = 'Deal gần đây';
include template('team_recent');

function current_teamcategory($gid='0') {
	global $city;
	$a = array(
			'/team/index.php' => 'All',
			);
	foreach(option_hotcategory('group') AS $id=>$name) {
		$a["/team/index.php?gid={$id}"] = $name;
	}
	$l = "/team/index.php?gid={$gid}";
	if (!$gid) $l = "/team/index.php";
	return current_link($l, $a, true);
}
