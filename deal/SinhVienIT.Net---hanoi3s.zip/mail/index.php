<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Template email</title>
</head>

<body>
<?php
require_once('../app.php');
$now = time();
$num = date("w");
if ($num == 0)
{ $sub = 6; }
else { $sub = ($num-1); }
$WeekMon  = mktime(0, 0, 0, date("m", $now)  , date("d", $now)-$sub, date("Y", $now));    //monday week begin calculation
$todayh = getdate($WeekMon); //monday week begin reconvert

$d = $todayh[mday];
$m = $todayh[mon];
$y = $todayh[year];
$_root=$INI['system']['wwwprefix'];

$daytime = strtotime(date('Y-m-d H:i:s'));
if(!$_REQUEST['id']) {
$condition = array(
	'team_type' => 'normal',
	'city_id' => array(0, abs(intval($city['id']))),
	"end_time   >= '{$daytime}'",
	"begin_time <= '{$daytime}'",
);
}
$count = Table::Count('team', $condition);
list($pagesize, $offset, $pagestring) = pagestring($count, 100);
$teams = DB::LimitQuery('team', array(
	'condition' => $condition,
	'order' => ' ORDER BY begin_time DESC, sort_order DESC, id DESC',
	'size' => $pagesize,
	'offset' => $offset,
));
?>
<div><form method="get" name="frm" action="">Xuất template gửi mail khách hàng:
<select name="id">
<option value="">---------Vui lòng chọn ---------</option>
<?php
foreach($teams AS $id=>$team){
?>
<option value="<?=$team['id']?>" <?=$_REQUEST['id']==$team['id']?'selected="selected"':''?>><?=$team['id']?>.<?=$team['product']?></option>
<?php }?>
</select>
&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="OK" />
</form>
</div>

<hr />
<div bgcolor="#dddddd" text="#353535" link="#000000" vlink="#000000" alink="#000000">
<table width="100%" cellspacing="0" cellpadding="0" border="0">
<colgroup>
<col width="100%">
</colgroup>
<tbody><tr>
<td width="100%" valign="top" bgcolor="#00CC00" align="center">
<table width="700" cellspacing="0" cellpadding="0" border="0">
<colgroup>
<col width="700">
</colgroup>
<tbody><tr>
<td height="7" width="700"><a name="13431c697b74faeb_134312bb330284b8_top_of_mail"></a></td>
</tr>
<tr>
<td height="2"><img height="2" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td align="center">
<table cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td valign="top" align="left"><font size="1" face="Arial, Helvetica, sans-serif" color="#000000" style="font-size: 10px;">Xem giá tốt của HN3S</font></td>
<td width="18" valign="top" align="center"><font size="1" face="Arial, Helvetica, sans-serif" color="#000000" style="font-size: 10px;">|</font></td>
<td valign="top" align="left"><a target="_blank" style="color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;" href="http://www.hanoi3s.com"><font size="1" face="Arial, Helvetica, sans-serif" color="#0f5f92" style="font-size: 10px; color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;">HaNoi3S.CoM</font></a></td>
<td valign="top" align="left"><table cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="18" valign="top" align="center"><font size="1" face="Arial, Helvetica, sans-serif" color="#000000" style="font-size: 10px;">|</font></td>

</tr>
</tbody></table></td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td height="2"><img height="2" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td align="center"><font size="1" face="Arial, Helvetica, sans-serif" color="#000000" style="font-size: 10px; line-height: 18px;">Vui lòng thêm <a target="_blank" style="line-height: 18px; color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;" href="mailto:hoaisg1986@gmail.com"><font size="1" face="Arial, Helvetica, sans-serif" color="#0f5f92" style="font-size: 10px; line-height: 18px; color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;">cdttvn@gmail.com</font></a> vào sổ liên lạc hoặc danh sách an toàn để chắc chắn rằng bạn nhận được email trong Hộp thư đến.</font></td>
</tr>
<tr>
<td height="11"><img height="11" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td height="111" valign="top" bgcolor="#66CCFF" align="center" style="background-repeat: repeat-x;">
<table width="700" cellspacing="0" cellpadding="0" border="0">
<colgroup>
<col width="700">
</colgroup>
<tbody><tr>
<td width="700" align="left">
<table width="700" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="12"><img hspace="0" height="1" width="12" src="<?=$_root?>/mail/img/trans.gif"></td>
<td valign="top" align="left">
<table cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td height="34"><img height="34" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td align="left"><a target="_blank" style="line-height: 18px; color: rgb(255, 255, 255); font-weight: normal; text-decoration: none;" href="http://www.hanoi3s.com"><font size="5" face="Arial, Helvetica, sans-serif" color="#ffffff" style="font-size: 20px; color: rgb(255, 255, 255); font-weight: normal; text-decoration: none;"><img hspace="0" height="56" vspace="0" border="0" style="display: block;" alt="HaNoi3S.CoM - Thách thức mọi bão giá!" src="<?=$_root?>/logo.png"></font></a></td>
</tr>
</tbody></table>
</td>
<td valign="top" align="right">
<table cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td height="29"><img height="29" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td align="right"><font size="2" face="Arial, Helvetica, sans-serif" color="#FFFFFF" style="font-size: 12px; line-height: 14px;"><? echo "Ngày ".date("d", $now)." tháng ".date("m", $now)." năm ".date("Y", $now);?></font></td>
</tr>
<tr>
<td height="9" style="background-repeat: no-repeat;"><img height="9" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td height="34" valign="middle" style="background-repeat: no-repeat;">
<table width="239" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="32"><img hspace="0" height="1" width="32" src="<?=$_root?>/mail/img/trans.gif"></td>
<td width="207" align="center"><font size="4" face="Arial, Helvetica, sans-serif" color="#FFFFFF" style="font-size: 18px;">Tp. Hồ Chí Minh</font></td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td valign="top" bgcolor="#E5E5E5" align="center">
<table width="700" cellspacing="0" cellpadding="0" border="0">
<colgroup>
<col width="700">
</colgroup>
<tbody><tr>
<td height="20" width="700"><img height="20" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td bgcolor="#ffffff" align="left">
<table width="700" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="9"><img hspace="0" height="10" width="9" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/bol.gif"></td>
<td width="682"><img hspace="0" height="10" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
<td width="9"><img hspace="0" height="10" width="9" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/bor.gif"></td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td bgcolor="#ffffff" align="left">
<?php

$daytime = strtotime(date('Y-m-d H:i:s'));
if($_REQUEST['id']) {
$team = Table::Fetch('team',$_REQUEST['id']);

$href=$INI['system']['wwwprefix']."/".ThietKeTrangChu_SEO($city['name'])."/".ThietKeTrangChu_SEO($team['product'])."-".$team['id'].".html";
?>
<table width="700" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="15"><img hspace="0" height="1" width="15" src="<?=$_root?>/mail/img/trans.gif"></td>
<td width="667" align="left">
<table width="667" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="338" valign="top" align="left">
<table width="338" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td height="10" width="338"><img height="10" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td height="1"><img hspace="0" height="1" width="338" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/bo.jpg"></td>
</tr>
<tr>
<td align="left">
<table width="338" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="3"><img hspace="0" height="225" width="3" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/bl.jpg"></td>
<td width="332" align="left">
<table width="332" cellspacing="0" cellpadding="5" border="0">
<tbody><tr>
<td width="332" valign="top" align="left" style="padding: 5px;"><a target="_blank" href="<?=$href?>">
<img hspace="0" height="215" width="322" vspace="0" border="0" style="display: block;" src="<?=$INI['system']['wwwprefix']?>/static/<?=$team['image']?>"></a></td>
</tr>
</tbody></table>
</td>
<td width="3"><img hspace="0" height="225" width="3" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/br.jpg"></td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td height="6"><img hspace="0" height="6" width="338" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/bu.jpg"></td>
</tr>
</tbody></table>
</td>
<td width="18"><img hspace="0" height="1" width="18" src="<?=$_root?>/mail/img/trans.gif"></td>
<td width="311" valign="top" align="left">
<table cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td height="6"><img height="6" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td align="left"><font size="3" face="Arial, Helvetica, sans-serif" color="#0f5f92" style="font-size: 16px; line-height: 22px;"><?=$team['title']?></font></td>
</tr>
<tr>
<td height="18"><img height="18" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td align="left">
<table width="311" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td valign="middle" align="left">
<table cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td bgcolor="#31982d" align="left"><a target="_blank" style="color: rgb(255, 255, 255); font-weight: bold; text-decoration: none;" href="<?=$href?>"><font size="5" face="Arial, Helvetica, sans-serif" color="#ffffff" style="font-size: 20px; color: rgb(255, 255, 255); font-weight: bold; text-decoration: none;"><img hspace="0" height="42" width="127" vspace="0" border="0" style="display: block;" alt="XEM" src="<?=$_root?>/mail/img/button.jpg"></font></a></td>
</tr>
</tbody></table>
</td>
<td width="5"><img hspace="0" height="1" width="5" src="<?=$_root?>/mail/img/trans.gif"></td>
<td valign="middle" align="right"><font size="8" face="Arial, Helvetica, sans-serif" color="#FF0000" style="font-size: 26px; line-height: 48px; color:#FF0000; font-weight: bold; text-decoration: none;"><b><?=number_format(moneyit($team['team_price']),0,'.','.')?></b><font size="1" face="Arial, Helvetica, sans-serif" color="#f99431" style="font-size: 10px; line-height: 48px;">VNĐ</font></font></td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td height="17"><img height="17" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td align="left">
<table cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="50"><img hspace="0" height="1" width="50" src="<?=$_root?>/mail/img/trans.gif"></td>
<td valign="top" align="center"><font size="1" face="Arial, Helvetica, sans-serif" color="#555555" style="font-size: 24px; color: rgb(85, 85, 85); font-weight: normal; text-decoration: none;"><?=round(moneyit((100*($team['market_price'] - $team['team_price'])/$team['market_price'])))?>%<font size="1" face="Arial, Helvetica, sans-serif" color="#555555" style="font-size: 10px;"><br>
tiết kiệm</font></font></td>
<td width="14"><img hspace="0" height="1" width="14" src="<?=$_root?>/mail/img/trans.gif"></td>
<td width="1" bgcolor="#bababa"><img hspace="0" height="1" width="1" src="<?=$_root?>/mail/img/trans.gif"></td>
<td width="24"><img hspace="0" height="1" width="24" src="<?=$_root?>/mail/img/trans.gif"></td>
<td valign="top" align="center"><font size="1" face="Arial, Helvetica, sans-serif" color="#555555" style="font-size: 24px; color: rgb(85, 85, 85); font-weight: normal; text-decoration: none;"><?=number_format($team['market_price'],0,'.','.')?><font size="1" face="Arial, Helvetica, sans-serif" color="#555555" style="font-size: 10px;">VNĐ<br>
giá gốc</font></font></td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td height="27"><img height="27" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td valign="middle" align="center">
<table cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="5"><img hspace="0" height="1" width="5" vspace="0" src="<?=$_root?>/mail/img/trans.gif"></td>

<td width="5"><img hspace="0" height="1" width="5" vspace="0" src="<?=$_root?>/mail/img/trans.gif"></td><td width="5"><img hspace="0" height="1" width="5" vspace="0" src="<?=$_root?>/mail/img/trans.gif"></td>

<td width="5"><img hspace="0" height="1" width="5" vspace="0" src="<?=$_root?>/mail/img/trans.gif"></td></tr>
</tbody></table>
</td>
</tr>
</tbody></table>
</td>
</tr>
<tr><td colspan="4"><?=$team['detail']?></td></tr>
</tbody></table>
</td>
<td width="18"><img hspace="0" height="1" width="18" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
</tbody></table>
<table width="700" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td height="10" colspan="3"><img height="10" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td width="18"><img hspace="0" height="1" width="18" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
<td height="1" bgcolor="#e5e5e5"><img height="1" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
<td width="18"><img hspace="0" height="1" width="18" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
</tbody></table>

<?php }?>

</td>
</tr><tr>
<td height="30" bgcolor="#ffffff"><img height="30" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td height="1" bgcolor="#e5e5e5"><img height="1" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td height="17" bgcolor="#ffffff"><img height="17" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td bgcolor="#ffffff" align="left">
<table width="700" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="9"><img hspace="0" height="10" width="9" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/bul.gif"></td>
<td width="682"><img hspace="0" height="10" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
<td width="9"><img hspace="0" height="10" width="9" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/bur.gif"></td>
</tr>
</tbody></table>
</td>
</tr>
<tr>
<td height="13"><img height="13" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td valign="top" align="center"><font size="1" face="Arial, Helvetica, sans-serif" color="#000000" style="font-size: 10px; line-height: 16px;">Bạn nhận được email này vì bạn đã dùng email này để đăng ký nhận Thông báo giá tốt hàng ngày từ <a target="_blank" style="line-height: 16px; color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;" href="http://www.hanoi3s.com"><font size="1" face="Arial, Helvetica, sans-serif" color="#0f5f92" style="font-size: 10px; line-height: 16px; color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;">HN3S</font></a></font></td>
</tr>

<tr>
<td height="6"><img height="6" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td valign="top" align="center"><font size="1" face="Arial, Helvetica, sans-serif" color="#000000" style="font-size: 10px; line-height: 16px;"><a target="_blank" style="line-height: 16px; color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;" href="#"><font size="1" face="Arial, Helvetica, sans-serif" color="#0f5f92" style="font-size: 10px; line-height: 16px; color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;">Thoả thuận sử dụng</font></a> <a target="_blank" href="http://www.hanoi3s.com">HaNoi3S.CoM</a></font></td>
</tr>
<tr>
<td height="12"><img height="12" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td height="1" bgcolor="#cccccc"><img height="1" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td height="9"><img height="9" width="1" vspace="0" style="display: block;" src="<?=$_root?>/mail/img/trans.gif"></td>
</tr>
<tr>
<td align="left">
<table width="700" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td width="70"><img hspace="0" height="1" width="70" src="<?=$_root?>/mail/img/trans.gif"></td>
<td width="315" valign="top" align="left">
<table width="315" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td align="left"><table width="315" cellspacing="0" cellpadding="0" border="0">
<tbody><tr>
<td align="left"><font size="2" face="Arial, Helvetica, sans-serif" color="#464646" style="font-size: 11px; color: rgb(70, 70, 70); font-weight: normal; text-decoration: none; line-height: 16px;"><b>Chia sẽ niềm vui mua sắm</b></font></td>
</tr>
<tr>
<td align="left"><font size="2" face="Arial, Helvetica, sans-serif" color="#464646" style="font-size: 11px; line-height: 16px;">101 - A1 - Ngõ 1 - Khâm Thiên - Đống Đa - HN<br>
   Điện thoại: 0934.39.11.25 </font></td>
</tr>
</tbody></table></td>
</tr>
</tbody></table>
</td>
<td width="315" valign="top" align="left">

</td>
</tr>
<tr>
<td align="center" colspan="3"><font size="2" face="Arial, Helvetica, sans-serif" color="#464646" style="font-size: 11px; line-height: 16px;">Email: <a target="_blank" style="color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;" href="mailto:cdttvn@gmail.com"><font size="2" face="Arial, Helvetica, sans-serif" color="#0f5f92" style="font-size: 11px; line-height: 16px; color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;">cdttvn@gmail.com</font></a></font></td>
</tr>
<tr>
<td align="center" colspan="3"><font size="2" face="Arial, Helvetica, sans-serif" color="#464646" style="font-size: 11px; line-height: 16px;">Website: <a target="_blank" style="color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;" href="http://www.hanoi3s.com"><font size="2" face="Arial, Helvetica, sans-serif" color="#0f5f92" style="font-size: 11px; line-height: 16px; color: rgb(15, 95, 146); font-weight: normal; text-decoration: none;">http://www.hanoi3s.com</font></a></font></td>
</tr>	</tbody></table>
</td>
</tr>

</tbody></table>
</td>
</tr>
</tbody></table>
</div>
</body>
</html>
