<?php
require_once(dirname(__FILE__) . '/app.php');
$daytime = strtotime(date('Y-m-d'));
if(!$_REQUEST['id']) {
$condition = array(
	'team_type' => 'normal',
	'city_id' => array(0, abs(intval($city['id']))),
	"end_time   >= '{$daytime}'",
);
}
else {
$condition = array(
	'team_type' => 'normal',
	"id   = '{$id}'",
);
}


/* Dem tong cong tat ca san pham Deal*/
$sp_city = array(
	'city_id' => array(0, abs(intval($city['id']))),
);
$sp_all = Table::Count('team', $sp_city);


/* id khong ton tai*/
$id = abs(intval($_GET['id']));
if (!$id || !$team = Table::FetchForce('team', $id) ) {
	redirect( WEB_ROOT . '/team/index.php');
}

/* refer */
if ($_rid = abs(intval($_GET['r']))) { 
	if($_rid) cookieset('_rid', abs(intval($_GET['r'])));
	redirect( WEB_ROOT . "/team.php?id={$id}");
}

$teamcity = Table::Fetch('category', $team['city_id']);
$city = $teamcity ? $teamcity : $city;
$city = $city ? $city : array('id'=>0, 'name'=>'All');

$pagetitle = $team['title'];

$discount_price = $team['market_price'] - $team['team_price'];
$discount_rate = team_discount($team);

$left = array();
$now = time();
$diff_time = array();
$count = Table::Count('team', $condition);
list($pagesize, $offset, $pagestring) = pagestring($count, 10);
$teams = DB::LimitQuery('team', array(
	'condition' => $condition,
	'order' => $idteam.' ORDER BY begin_time DESC, sort_order DESC, id DESC',
	'size' => $pagesize,
	'offset' => $offset,
));
foreach($teams AS $id=>$team){
	team_state($team);
	if (!$team['close_time']) $team['picclass'] = 'isopen';
	if ($team['state']=='soldout') $team['picclass'] = 'soldout';
	if($team['end_time']<$team['begin_time']){$team['end_time']=$team['begin_time'];}
$diff_time = $left_time = $team['end_time']-$now;
if ( $team['team_type'] == 'seconds' && $team['begin_time'] >= $now ) {
	$diff_time = $left_time = $team['begin_time']-$now;
}
	$team['diff_time']=$diff_time;
	$team['left_time']=$left_time;
	

	$team['url']=$INI['system']['wwwprefix']."/".ThietKeTrangChu_SEO($city['name'])."/".ThietKeTrangChu_SEO($team['product'])."-".$team['id'].".html";
	$bix = DB::LimitQuery('partner', array(
		'condition' => array(
			'id' => $team['partner_id'],
		),
		'one' => true,
	));
	$partner['title']=$bix['title'];
	$partner['image']=$bix['image'];
	$partner['other']=$bix['other'];
	$teams[$id] = $team;
}

/* your order */
if ($login_user_id && 0==$team['close_time']) {
	$order = DB::LimitQuery('order', array(
				'condition' => array(
					'team_id' => $id,
					'user_id' => $login_user_id,
					'state' => 'unpay',
					),
				'one' => true,
				));
}
/* end order */

/*kxx team_type */
if ($team['team_type'] == 'seconds') {
	die(include template('team_view_seconds'));
}
if ($team['team_type'] == 'goods') {
	die(include template('team_view_goods'));
}
/*xxk*/

/*seo*/
$seo_title = $team['seo_title'];
$seo_keyword = $team['seo_keyword'];
$seo_description = $team['seo_description'];
/*end*/
if(!$_REQUEST['id'])
include template('team_index');
else
include template('team_view');