<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

$page = Table::Fetch('page', 'content_pay');
$pagetitle = 'Thanh toán trực tiếp';
include template('content_pay');
