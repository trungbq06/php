<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

$page = Table::Fetch('page', 'content_money');
$pagetitle = 'Quy định hoàn tiền';
include template('content_money');
