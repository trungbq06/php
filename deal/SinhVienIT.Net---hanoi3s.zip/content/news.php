<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

$page = Table::Fetch('page', 'content_news');
$pagetitle = 'Thông báo mới - Tin nóng';
include template('content_news');
