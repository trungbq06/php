<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

$page = Table::Fetch('page', 'content_seller');
$pagetitle = 'Hợp tác kinh doanh';
include template('content_seller');
