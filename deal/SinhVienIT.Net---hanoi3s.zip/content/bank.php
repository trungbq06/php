<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

$page = Table::Fetch('page', 'content_bank');
$pagetitle = 'Thanh toán chuyển khoản';
include template('content_bank');
