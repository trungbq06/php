<?php
require_once('../app.php');
$dist1 =explode("-",$login_user['dist']);
$condition = array(
							'parent' => $_GET['town'],
							);
						    $dist = DB::LimitQuery('ward-dist', array(
							'condition' => $condition,
							'order' => ' ORDER BY sort ',
							));
							echo '<select name="ward_id" id="ward_id" class="f-input" require="true" datatype="require">';
							foreach($dist AS $id=>$dist){
							if($dist['id']==$dist1[1]) $select='selected="selected"';
								echo "<option ".$select." value=".$dist['id'].">".$dist['name']."</option>" ;
							
							}
							echo '</select>';
?>