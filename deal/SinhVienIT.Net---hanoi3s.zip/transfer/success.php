<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

$pagetitle = 'Thông báo chuyển khoản thành công';
include template('transfer_success');
