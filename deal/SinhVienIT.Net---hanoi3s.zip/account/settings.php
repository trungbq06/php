<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

need_login();
if ( $_POST ) {
	$update = array();
	$update['email'] = $_POST['email'];
    $update['address'] = strval($_POST['street_name']);
	$update['realname'] = strval($_POST['realname']);
	$update['zipcode']=$_POST['zipcode'];
	$update['mobile']=$_POST['mobile'];
	$update['gender']=$_POST['gender'];
	$update['city_id']=$_POST['city_id'];
	$update['qq']=$_POST['qq'];
	$update['dist']=$_POST['dist_name'];
	$update['ward']=$_POST['ward_name'];
	$update['birthday']=$_POST['dob_d']."-".$_POST['dob_m']."-".$_POST['dob_y'];
	$update['house_no']=$_POST['house_number'];
	$update['room']=$_POST['note_address'];
	
	$avatar = upload_image('upload_image',$login_user['avatar'],'user');
	$update['avatar'] = $avatar;

	if ( $_POST['password'] == $_POST['password2']
			&& $_POST['password'] 
			&& strtolower(md5($email)) != 'f7e0dcf82fd5d444b11cb42db2a8da3e' ) 
	{
		$update['password'] = $_POST['password'];
	}

	if ( ZUser::Modify($login_user['id'], $update) ) {
		Session::Set('notice', 'Cập nhật thông tin thành công');
		redirect( WEB_ROOT . '/account/settings.php ');
	} else {
		Session::Set('error', 'Có lỗi, vui lòng kiểm tra lại');
	}
}

$readonly['email'] = defined('UC_API') ? '' : 'readonly';
$readonly['username'] = defined('UC_API') ? 'readonly' : '';

$pagetitle = 'Thiết lập tài khoản';
include template('account_settings');
