<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');
$pagetitle = 'Ðăng ký hay Đăng nhập vào '.$INI['system']['sitename'];
include template('account_loginup');
