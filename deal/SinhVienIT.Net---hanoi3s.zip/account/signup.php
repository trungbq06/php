<?php
require_once(dirname(dirname(__FILE__)) . '/app.php');

if ( $_POST ) {
	$u = array();
	$u['username'] = md5(rand(1000000,9999999).time());
	$u['password'] = strval($_POST['password']);
	$u['email'] = strval($_POST['email']);
	$u['dist'] = strval($_POST['dist_name']);
	$u['ward'] = strval($_POST['ward_name']);
	$u['city_id'] = isset($_POST['city_id']) 
		? abs(intval($_POST['city_id'])) : abs(intval($city['id']));
	$u['realname'] = strval($_POST['realname']);	
	$u['mobile'] = strval($_POST['mobile']);
	$u['address'] = strval($_POST['street_name']);
	$u['birthday'] = strval($_POST['dob_d'])."-".strval($_POST['dob_m'])."-".strval($_POST['dob_y']);
	$u['house_no'] = strval($_POST['house_number']);
	$u['room'] = strval($_POST['note_address']);
	
	if ( $_POST['subscribe'] ) { 
		ZSubscribe::Create($u['email'], abs(intval($u['city_id']))); 
	}
	if ( ! Utility::ValidEmail($u['email'], true) ) {
		Session::Set('error', 'Địa chỉ email không hợp lệ');
		redirect( WEB_ROOT . '/account/signup.php');
	}
	if ($_POST['password2']==$_POST['password'] && $_POST['password']) {
		if ( option_yes('emailverify') ) { 
			$u['enable'] = 'Y'; 
		}
		if ( $user_id = ZUser::Create($u) ) {
			if ( option_yes('emailverify') ) {
				mail_sign_id($user_id);
				Session::Set('unemail', $_POST['email']);
				redirect( WEB_ROOT . '/account/signuped.php');
			} else {
				ZLogin::Login($user_id);
				redirect(get_loginpage(WEB_ROOT . '/index.php'));
			}
		} else {
			$au = Table::Fetch('user', $_POST['email'], 'email');
			if ( $au ) {
				Session::Set('error', 'Địa chỉ email đã tồn tại!');
			} else {
				Session::Set('error', 'Số đi động này đã có người dùng!');
			}
		}
	} else {
		Session::Set('error', 'Mật khẩu không trùng khớp.');
	}
}

$pagetitle = 'Đăng ký tài khoản '.$INI['system']['sitename'];
include template('account_signup');
