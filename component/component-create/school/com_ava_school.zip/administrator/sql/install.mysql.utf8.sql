CREATE TABLE IF NOT EXISTS `#__kc_school` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',

`name` VARCHAR(50)  NOT NULL ,
`address` VARCHAR(50)  NOT NULL ,
`phone_number` VARCHAR(50)  NOT NULL ,
`fax` VARCHAR(50)  NOT NULL ,
`email` VARCHAR(50)  NOT NULL ,
`website` VARCHAR(50)  NOT NULL ,
`manager` VARCHAR(50)  NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8_general_ci;

