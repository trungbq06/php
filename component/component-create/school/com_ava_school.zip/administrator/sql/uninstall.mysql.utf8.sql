DROP TABLE IF EXISTS `#__kc_school`;
