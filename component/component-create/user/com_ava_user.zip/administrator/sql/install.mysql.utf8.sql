CREATE TABLE IF NOT EXISTS `#__kc_user` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',

`school_id` VARCHAR(255)  NOT NULL ,
`name` VARCHAR(50)  NOT NULL ,
`phone_number` VARCHAR(50)  NOT NULL ,
`email` VARCHAR(50)  NOT NULL ,
`address` VARCHAR(50)  NOT NULL ,
`job` VARCHAR(50)  NOT NULL ,
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8_general_ci;

