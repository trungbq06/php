DROP TABLE IF EXISTS `#__kc_user`;
