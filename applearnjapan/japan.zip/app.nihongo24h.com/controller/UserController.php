<?php
	include '../entity/clsUser.php';		
	include '../dao/UserDAO.php';
		
	$action = $_POST["action"];
	
	if($action == 'login'){
		$username = $_POST["username"];
		$password = $_POST["password"];

		$user = login($username, $password);
		if($user != null){
			session_start();
			$_SESSION['user'] = json_encode($user);
			$url = "Location:../index.php";
			Header($url);
		}else{
			$message = 'Tài Khoản Hoặc Mật Khẩu Không Đúng!';
			$url = "Location:../login.php?message=".$message."";
			Header($url);
		}
			
	} else if($action == 'register'){
		$username = $_POST["username"];
		$password = $_POST["password"];
		$fullName = $_POST["fullName"];
		$phone = $_POST["phone"];
		$email = $_POST["email"];
		
		$user = checkUser($username);
		if($user != null){
			$message = 'Tài Khoản Đã Tồn Tại!';
			$url = "Location:../register.php?message=".$message."";
			Header($url);
		} else {
			createUser($username, $password, $fullName, $phone, $email);
			$message = 'Bạn Đã Tạo Tài Khoản Thành Công. Mời Bạn Đăng Nhập!';
			$url = "Location:../login.php?message=".$message."";
			Header($url);
		}		
	} else if($action == 'updateStatusActive'){
		$id = $_POST["id"];
		$status = $_POST["status"];
		
		$today = date('Y-m-d');
		$date = $today;
		if ($status == '1') {
			$year = strtotime(date("Y-m-d", strtotime($today)) . " +1 year");
			$date = strftime("%Y-%m-%d", $year);		
		}
		updateStatusActive($id, $date);
		
		$url = "Location:../manage-list-user.php";
		Header($url);
	} else {
		session_start();
		session_destroy();
		$url = "Location:../index.php";
		Header($url);
	}
?>