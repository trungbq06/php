<?php
	include '../entity/clsQuestion.php';		
	include '../dao/QuestionDAO.php';
		
	$action = $_POST["action"];
	
	if($action == 'add'){
		$title = $_POST["title"];
		$idSubMenu = $_POST["idSubMenu"];
				
		createQuestion($title, $idSubMenu);
		$url = "Location:../add-test.php";
		Header($url);		
	}else if($action == 'delete'){
		$id = $_POST["id"];
		$idSubMenu = $_POST["idSubMenu"];
		deleteQuestion($id);
		$url = "Location:../manage-list-test.php?action=search&idSubMenu=".$idSubMenu;
		Header($url);		
	}
?>