<?php
	include '../entity/clsSubMenu.php';		
	include '../dao/SubMenuDAO.php';
		
	$action = $_POST["action"];
	
	if($action == 'add'){
		$name = $_POST["name"];
		$indexMenu = $_POST["indexMenu"];
		$idMenu = $_POST["idMenu"];		
				
		createSubMenu($name, $indexMenu, $idMenu);
		$url = "Location:../add-menu.php";
		Header($url);		
	}
?>