<?php
	include '../entity/clsDetailsQuestion.php';		
	include '../dao/DetailsQuestionDAO.php';
		
	$action = $_POST["action"];
	
	if($action == 'add'){
		$idSubMenu = $_POST["idSubMenu"];
		$content = $_POST["content"];
		$answerA = $_POST["answerA"];
		$answerB = $_POST["answerB"];
		$answerC = $_POST["answerC"];
		$answerD = $_POST["answerD"];
		$answer = $_POST["answer"];		
		$idQuestion = $_POST["idQuestion"];
				
		if(isset($_POST['answerA']) && isset($_POST['answer']) && isset($_POST['idQuestion'])){	
			createDetailsQuestion($content, $answerA, $answerB, $answerC, $answerD, $answer, $idQuestion);
		}
		$url = "Location:../add-question.php?idSubMenu=".$idSubMenu."&idQuestion=".$idQuestion;
		Header($url);		
	}else if($action == 'delete'){
		$id = $_POST["id"];
		$idSubMenu = $_POST["idSubMenu"];
		$idQuestion = $_POST["idQuestion"];		
		deleteDetailsQuestion($id);
		$url = "Location:../manage-list-question.php?action=search&idSubMenu=".$idSubMenu."&idQuestion=".$idQuestion;
		Header($url);		
	}
?>