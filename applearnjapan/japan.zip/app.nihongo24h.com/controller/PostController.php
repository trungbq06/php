<?php
	include '../entity/clsPost.php';		
	include '../dao/PostDAO.php';
		
	$action = $_POST["action"];
	
	if($action == 'add'){
		$title = $_POST["title"];
		$content = $_POST["content"];
		$idSubMenu = $_POST["idSubMenu"];		
				
		createPost($title, $content, $idSubMenu);
		$url = "Location:../add-post.php?idSubMenu=".$idSubMenu;
		Header($url);		
	}else if($action == 'delete'){
		$id = $_POST["id"];
		$idSubMenu = $_POST["idSubMenu"];
		deletePost($id);
		$url = "Location:../manage-list-post.php?action=search&idSubMenu=".$idSubMenu;
		Header($url);		
	}
?>