<?php
	include '../entity/clsUser.php';		
	include '../dao/UserDAO.php';
		
	$action = $_POST["action"];
	
	if($action == 'login'){
		$username = $_POST["username"];
		$password = $_POST["password"];
		
		if($username == 'admin' && $password == '12345678'){
			session_start();
			$_SESSION['admin'] = 1;	
			$url = "Location:../index.php";
			Header($url);
		}else{
			$message = 'Tài Khoản Hoặc Mật Khẩu Không Đúng!';
			$url = "Location:../admin.php?message=".$message."";
			Header($url);
		}
			
	}
?>