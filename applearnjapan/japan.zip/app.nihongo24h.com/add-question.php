<?php
	session_start();
	include 'entity/clsSubMenu.php';		
	include 'dao/SubMenuDAO.php';
	include 'entity/clsPost.php';		
	include 'dao/PostDAO.php';
	include 'entity/clsQuestion.php';		
	include 'dao/QuestionDAO.php';
	include 'entity/clsDetailsQuestion.php';		
	include 'dao/DetailsQuestionDAO.php';
	include 'entity/clsLogCard.php';		
	include 'dao/LogCardDAO.php';
	include 'entity/clsUser.php';		
	include 'dao/UserDAO.php';
	if(!isset($_SESSION['admin'])){
		$url = "Location:index.php";
		Header($url);		
	}
?>
<html>
    <head>
        <title>Add Question</title>
		<?php include 'templates/css-js.php';?>
		<script src="ckeditor/ckeditor.js"></script>
		<script src="ckeditor/samples/js/sample.js"></script>
		<!--[if lt IE 9]>
		<script src="js/html5shiv.min.js"></script>
		<![endif]-->
		<style type="text/css">
		.progress {
			position: relative;
		}

		.progress-text {
			position: absolute;
			width: 100%;
			height: 100%;
			text-align: right;
			padding-right: 5px;
			color: #333;
		}
		</style>
    </head>
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">
			<?php include 'templates/header.php';?>
            <!-- Left side column. contains the logo and sidebar -->            
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>Thêm Câu Hỏi</h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                        <li class="active">Thêm Câu Hỏi</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content"> 
					<div class="row">
						<form id="defaultForm" method="post" action="controller/DetailsQuestionController.php">
						<input type="hidden" name="action" value="add" />
							<div class="col-md-6">															
								<div class="form-group">
									<label for="exampleInputEmail1">Menu Con</label>
									<select name="idSubMenu" class="form-control" onchange="this.form.submit()">
										<?php	
											$idSubMenu = 0;
											if(isset($_GET['idSubMenu'])){	
												$idSubMenu = $_GET['idSubMenu'];
											}
											$subMenu = getAllSubMenu(2);								
											$count = 0;
											$idSubMenuTemp = 0;
											foreach ($subMenu as $m) {
												if($count == 0){
													$idSubMenuTemp = $m->id;
													$count += 1;
												}
										?>
										<option value="<?php echo $m->id ?>" <?php if($idSubMenu == $m->id) echo 'selected'; ?>><?php echo $m->name ?></option>
										<?php
											}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">															
								<div class="form-group">
									<label for="exampleInputEmail1">Đề</label>
									<select name="idQuestion" class="form-control">
										<?php		
											if($idSubMenu == 0){
												$idSubMenu = $idSubMenuTemp;
											}	
											$idQuestion = 0;
											if(isset($_GET['idQuestion'])){	
												$idQuestion = $_GET['idQuestion'];
											}
											$question = getAllQuestion($idSubMenu);								
											foreach ($question as $q) {		
										?>
										<option value="<?php echo $q->id ?>" <?php if($idQuestion == $q->id) echo 'selected'; ?>><?php echo $q->title ?></option>
										<?php
											}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-12">	
								<div class="form-group">
									<label for="exampleInputPassword1">Nội dung</label>
									<textarea id="editor" name="content" class="form-control">
									</textarea>
								</div>
							</div>
							<div class="col-md-6">															
								<div class="form-group">
									<input type="radio" name="answer" value="A"> A
									<input type="text" name="answerA" class="form-control">
								</div>
							</div>
							<div class="col-md-6">															
								<div class="form-group">									
									<input type="radio" name="answer" value="B"> B
									<input type="text" name="answerB" class="form-control">
								</div>
							</div>
							<div class="col-md-6">															
								<div class="form-group">									
									<input type="radio" name="answer" value="C"> C
									<input type="text" name="answerC" class="form-control">
								</div>
							</div>
							<div class="col-md-6">															
								<div class="form-group">									
									<input type="radio" name="answer" value="D"> D
									<input type="text" name="answerD" class="form-control">
								</div>
							</div>
							<div class="col-md-12">								
								<div class="form-group">
									<button type="submit" class="form-control btn btn-primary">Thêm</button>
								</div>							
							</div>							
						</form>				
					</div>
					<div class="row">
						<div class="col-md-12">								
							<form role="form" action="#" method="post" enctype="multipart/form-data" onsubmit="return doUpload();">
							  <div class="form-group">
								<label for="myfile">Upload ảnh và mp3</label>
								<input type="file" class="form-control" name="myfile" id="myfile" multiple>
							  </div>	  
							  <input type="submit" class="btn btn-default" value="Upload" />
							  <input type="button" class="btn btn-default" value="Cancle" onclick="cancleUpload();"/>
							</form>
							<div id="progress-group">
								<div class="progress">
								  <div class="progress-bar" style="width: 60%;">
									Tên file ở đây
								  </div>
								  <div class="progress-text">
									Tiến trình ở đây
								  </div>
								  
								</div>								
							</div>									
							<div id="content-code"></div>																			
						</div>
					</div>
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->
			<?php include 'templates/footer.php';?>
			<script>
				initSample();
			</script>
			<script>	
				var button1 = document.getElementById( 'ckfinder-modal-1' );
				
				button1.onclick = function() {
					selectFileWithCKFinder( 'ckfinder-input-1' );
				};	

				function selectFileWithCKFinder( elementId ) {
					CKFinder.modal( {
						chooseFiles: true,
						width: 800,
						height: 600,
						onInit: function( finder ) {
							finder.on( 'files:choose', function( evt ) {
								var file = evt.data.files.first();
								var output = document.getElementById( elementId );
								output.value = file.getUrl();
							} );

							finder.on( 'file:choose:resizedImage', function( evt ) {
								var output = document.getElementById( elementId );
								output.value = evt.data.resizedUrl;
							} );
						}
					} );
				}
			</script>
			<script type="text/javascript" src="css-js/js/function.js"></script>
        </div>        
    </body>	
</html>