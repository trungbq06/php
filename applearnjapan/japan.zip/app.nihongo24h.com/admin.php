<?php
	session_start();
	include 'entity/clsSubMenu.php';		
	include 'dao/SubMenuDAO.php';
	include 'entity/clsPost.php';		
	include 'dao/PostDAO.php';
	include 'entity/clsQuestion.php';		
	include 'dao/QuestionDAO.php';
	include 'entity/clsDetailsQuestion.php';		
	include 'dao/DetailsQuestionDAO.php';
	include 'entity/clsLogCard.php';		
	include 'dao/LogCardDAO.php';
	include 'entity/clsUser.php';		
	include 'dao/UserDAO.php';
?>
<html>
    <head>
        <title>Login</title>
		<?php include 'templates/css-js.php';?>
    </head>
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">
			<?php include 'templates/header.php';?>
            <!-- Left side column. contains the logo and sidebar -->            
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>Đăng Nhập</h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                        <li class="active">Đăng Nhập</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content body"> 					
					<div class="row">
						<div class="col-md-12">
							<?php 
							if(isset($_GET['message']))
								echo "<b style='color:red;'>".$_GET['message']."</b>";
							?>
							<form id="defaultForm" method="post" action="controller/AdminController.php">
								<input type="hidden" name="action" value="login" />
								<div class="form-group">
									<label for="exampleInputEmail1">Tài khoản</label>
									<input type="text" name="username" class="form-control" placeholder="Nhập tài khoản">
								</div>
								<div class="form-group">
									<label for="exampleInputPassword1">Mật khẩu</label>
									<input type="password" name="password" class="form-control" placeholder="Nhập mật khẩu">
								</div>															
								<div class="form-group">
									<button type="submit" class="form-control btn btn-primary">Đăng nhập</button>
								</div>
							</form>
						</div>					
					</div>					
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->
			<?php include 'templates/footer.php';?>
        </div>        
    </body>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#defaultForm').formValidation({
				message: 'This value is not valid',
				fields: {
					username: {
						validators: {
							notEmpty: {
								message: 'Tài khoản không được để trống'
							},
							stringLength: {
								min: 5,
								max: 25,
								message: 'Tài khoản phải có độ dài từ 5 đến 25'
							},
							regexp: {
								regexp: /^[a-zA-Z0-9_\.]+$/,
								message: 'Tên tài khoản chỉ bao gồm chữ, số ,dấu chấm và gạch dưới'
							}
						}
					},
					password: {
						validators: {
							notEmpty: {
								message: 'Mật khẩu không được để trống'
							},
							stringLength: {
								min: 8,
								message: 'Mật khẩu phải có độ dài ít nhất là 8'
							},
							regexp: {
								regexp: /^[a-zA-Z0-9_\.]+$/,
								message: 'Mật khẩu chỉ bao gồm chữ, số ,dấu chấm và gạch dưới'
							}
						}
					}
				}
			});
		});
	</script>
</html>