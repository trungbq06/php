<?php
	session_start();
	include 'entity/clsSubMenu.php';		
	include 'dao/SubMenuDAO.php';
	include 'entity/clsPost.php';		
	include 'dao/PostDAO.php';
	include 'entity/clsQuestion.php';		
	include 'dao/QuestionDAO.php';
	include 'entity/clsDetailsQuestion.php';		
	include 'dao/DetailsQuestionDAO.php';
	include 'entity/clsLogCard.php';		
	include 'dao/LogCardDAO.php';
	include 'entity/clsUser.php';		
	include 'dao/UserDAO.php';
	if(!isset($_SESSION['admin'])){
		$url = "Location:index.php";
		Header($url);		
	}
?>
<html>
    <head>
        <title>Add Question</title>
		<?php include 'templates/css-js.php';?>		
    </head>
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">
			<?php include 'templates/header.php';?>
            <!-- Left side column. contains the logo and sidebar -->            
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>Thêm Đề</h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                        <li class="active">Thêm Đề</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content"> 
					<div class="row">
						<div class="col-md-12">							
							<form id="defaultForm" method="post" action="controller/QuestionController.php">
								<input type="hidden" name="action" value="add" />
								<div class="form-group">
									<label for="exampleInputEmail1">Tiêu đề</label>
									<input type="text" name="title" class="form-control">
								</div>														
								<div class="form-group">
									<label for="exampleInputEmail1">Menu Con</label>									
									<select name="idSubMenu" class="form-control">
										<?php										
											$subMenu = getAllSubMenu(2);								
											foreach ($subMenu as $m) {		
										?>
										<option value="<?php echo $m->id ?>"><?php echo $m->name ?></option>
										<?php
											}
										?>
									</select>
								</div>								
								<div class="form-group">
									<button type="submit" class="form-control btn btn-primary">Thêm</button>
								</div>
							</form>
						</div>
					</div>
                </section>
                <!-- /.content -->
            </div>
            <!-- /.content-wrapper -->
			<?php include 'templates/footer.php';?>
        </div>        
    </body>	
</html>