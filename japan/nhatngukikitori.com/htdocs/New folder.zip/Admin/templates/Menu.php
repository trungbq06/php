<div>
    <ul id="mbt-menu"> 
	<li>
    <a href="Home.php" style="width:125px; text-align:center">Home</a>
    <li>
	
    <li>
    <a href="#"style="width:125px; text-align:center">Tài Khoản</a>
	 <ul>
	<li><a href="ThemTaiKhoan.php">● Thêm</a></li>
    <li><a href="XoaTaiKhoan.php">● Xóa</a></li>
    </ul>
    </li>
	
	<li>
    <a href="#"style="width:125px; text-align:center">DS Đăng Kí</a>
    <ul>
	<li><a href="DSSoCap.php">● Sơ Cấp</a></li>
    <li><a href="DSTrungCap.php">● Trung Cấp</a></li>
	<li><a href="DSThuongCap.php">● Thượng Cấp</a></li>
    </ul>
    </li>

	<li>
    <a href="#" style="width:125px; text-align:center">Tin Tức</a>
    <ul>
    <li><a href="ThemTinTuc.php">● Thêm</a></li>
    <li><a href="XoaTinTuc.php">● Xóa</a></li>
	</ul>
    <li>
	
	<li>
    <a href="#" style="width:125px; text-align:center">Thư Viện</a>
    <ul>
    <li><a href="#">● Học Tập</a>
	<ul>
    <li><a href="ThemTLHocTap.php">● Thêm</a></li>
    <li><a href="XoaTLHocTap.php">● Xóa</a></li>
	</ul>
	</li>
    <li><a href="#">● Album Ảnh</a>
	<ul>
    <li><a href="ThemAlbum.php">● Thêm</a></li>
    <li><a href="XoaAlbum.php">● Xóa</a></li>
	</ul>
	</li>
	  <li><a href="#">● Video</a>
	<ul>
    <li><a href="ThemVideo.php">● Thêm</a></li>
    <li><a href="XoaVideo.php">● Xóa</a></li>
	</ul>
	</li>
	</ul>
    <li>
	
	<li>
    <a href="#" style="width:125px; text-align:center">Câu Lạc Bộ</a>
    <ul>
    <li><a href="#">● Tin Tức CLB</a>
	<ul>
    <li><a href="ThemCLB.php">● Thêm</a></li>
    <li><a href="XoaCLB.php">● Xóa</a></li>
	</ul>
	</li>
    <li><a href="LichCLB.php">● Lịch Sinh Hoạt</a></li>
	</ul>
    <li>
	
	<li>
    <a href="#" style="width:125px; text-align:center">Lịch Khai Giảng</a>
    <ul>
    <li><a href="ThemKhaiGiang.php">● Thêm</a></li>
    <li><a href="XoaKhaiGiang.php">● Xóa</a></li>
	</ul>
    <li>
	
	<li>
    <a href="#" style="width:125px; text-align:center">Quảng Cáo</a>
	<ul>
    <li><a href="Slide.php">● Slide</a></li>
    <li><a href="Banner.php">● Banner</a></li>
	</ul>
    <li>
	
	<li>
    <a href="LienHe.php" style="width:125px; text-align:center">Liên Hệ</a>
    <li>
	
	<li>
    <a href="#" style="width:125px; text-align:center">
		<form method="post" action="../controller/AccountController.php">
			<button name="commit" value="Logout">Thoát </button>
		</form>
	</a>
    <li>
</div>