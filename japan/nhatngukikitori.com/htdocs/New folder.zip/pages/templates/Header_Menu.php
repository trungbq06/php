<div class="wrapper col1">
	<div style="margin-left: 193px; margin-right: 193px; background-color: #294e79;">
	  <div id="head">
		<a href="Home.php">
			<image src="images/logo/1240398_427175504059500_1348746955_n.png" style="width:100px" />
		</a>	
		<p>&nbsp;&nbsp;&nbsp;KIKITORI</p>
		<div id="topnav">
		  <ul>
			<li><a href="Home.php">Home</a></li>
			<li><a href="GioiThieu.php">Giới Thiệu</a></li>
			<li><a href="#">Khóa Học</a>
			<ul>
				<li><a href="KHSoCap.php">Sơ Cấp</a>
				<ul>
				<li><a href="KHSoCapKS1.php">Tiếng Nhật KS1</a></li>
				<li><a href="KHSoCapKS2.php">Tiếng Nhật KS2</a></li>
				<li><a href="KHSoCapKS3.php">Tiếng Nhật KS3</a></li>
				<li><a href="KHSoCapKS4.php">Tiếng Nhật KS4</a></li>
				<li><a href="KHSoCapKS5.php">Tiếng Nhật KS5</a></li>
				</ul>
				</li>
				<li><a href="#">Trung Cấp</a>
				<ul>
				<li><a href="KHTrungCap.php">Tiếng Nhật N3</a></li>
				</ul>
				</li>
				<li><a href="#">Thượng Cấp</a>
				<ul>
				<li><a href="KHThuongCapN1.php">Tiếng Nhật N1</a></li>
				<li><a href="KHThuongCapN2.php">Tiếng Nhật N2</a></li>
				</ul>
				</li>
				<li><a href="KHKhac.php">Các Khóa Học Khác</a></li>
			</ul>
			</li>
			<li><a href="TinTuc.php">Tin Tức</a></li>
			<li><a href="#">Thư Viện</a>
			<ul>
				<li><a href="TLHocTap.php">Học Tập</a></li>
				<li><a href="Album.php">Album Ảnh</a></li>
				<li><a href="Video.php">Video</a></li>
			</ul>
			</li>
			<li><a href="#">Câu Lạc Bộ</a>
			<ul>
				<li><a href="CLBTinTuc.php">Tin Tức CLB</a></li>
				<li><a href="ThamGiaCLB.php">Cách Thức Tham Gia</a></li>
				<li><a href="LichCLB.php">Lịch Sinh Hoạt</a></li>	
			</ul>
			</li>
			<li class="last"><a href="Forum.php">Diễn Đàn</a>
			</li>
		  </ul>
		</div>
		<div id="search">
		 <div class="block_topMenu">
			&nbsp;<a href="../Admin/Login.php" class="start" title="Admin" target="_self">Admin</a> &nbsp;&nbsp;|&nbsp;&nbsp;
			<a href="TuyenDung.php" title="Tuyển dụng" target="_self" rel="">Tuyển dụng</a>&nbsp;&nbsp;
			 <!--&nbsp;&nbsp;|&nbsp;<a href="/contact.html" title="Liên hệ" target="_self">Liên hệ</a> -->
			</ul>
		</div>
		</div>
	  </div>
	</div>
</div>