<style type="text/css">
#column p {
	text-align: justify;
}
</style>
<div id="column">
	<h2>Giới Thiệu KIKIRITO</h2>
	<iframe width="300" height="220" src="http://www.youtube.com/embed/CXQJpkhjeis?feature=oembed&amp;autoplay=1&amp;wmode=opaque&amp;rel=0&amp;showinfo=0&amp;modestbranding=1&amp;version=3&amp;ps=docs&amp;nologo=1&amp;theme=dark&amp;color=red&amp;iv_load_policy=3&amp;cc_load_policy=1" frameborder="0" allowfullscreen=""></iframe>
	<p>Chào mừng bạn đến với Hệ thống Đào tạo Nhật Ngữ KIKITORI.Vui lòng gọi điện hay gửi liên hệ nếu bạn cần tư vấn hoặc trợ giúp.</p>
	<p class="more"><img src="images/icon/Phone.png" alt=""/><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;0973300309 - 0902355395</b></p>
	  
	<br />
		
	<div class="imgholder">
	<h2>Hỗ Trợ Trực Tuyến !</h2>
	<p>		
		<img src="images/icon/Yahoo.png" border="0" alt="Kikitori" style="padding-left: 25px;">
		<a href="ymsgr:sendim?hiroshiheian&amp;m=Hello">
		Yahoo
		</a>
		
		<img src="images/icon/Skype.png" alt="Kikitori" style="padding-left: 45px;"/>
		<a href="skype:tiengnhat24h?chat">		
		Skype
		</a>
	</p>
	<p>
		<img src="images/icon/Yahoo.png" border="0" alt="Kikitori" style="padding-left: 25px;">
		<a href="ymsgr:sendim?mr_jackky&amp;m=Hello">
		Yahoo
		</a>
		<img src="images/icon/Skype.png" alt="Kikitori" style="padding-left: 45px;"/>
		<a href="skype:tiengnhatkikitori?chat">
		Skype
		</a>
	</p>
	</div>
	
	<div class="imgholder">
		<h2>Bản Đồ KIKITORI</h2>  
		<!-- Plugin Google Map --> 
		<iframe width="290" height="250" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=vi&amp;geocode=&amp;q=km+12+ph%C3%BA+di%E1%BB%85n+t%E1%BB%AB+li%C3%AAm&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=40.545434,86.572266&amp;ie=UTF8&amp;hq=km12+ph%C3%BA+di%E1%BB%85n&amp;hnear=T%E1%BB%AB+Li%C3%AAm,+H%C3%A0+N%E1%BB%99i,+Vi%E1%BB%87t+Nam&amp;t=m&amp;cid=1580520205527480740&amp;ll=21.047128,105.74645&amp;spn=0.011695,0.021136&amp;output=embed"></iframe><br /><small><a href="https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=vi&amp;geocode=&amp;q=km+12+ph%C3%BA+di%E1%BB%85n+t%E1%BB%AB+li%C3%AAm&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=40.545434,86.572266&amp;ie=UTF8&amp;hq=km12+ph%C3%BA+di%E1%BB%85n&amp;hnear=T%E1%BB%AB+Li%C3%AAm,+H%C3%A0+N%E1%BB%99i,+Vi%E1%BB%87t+Nam&amp;t=m&amp;cid=1580520205527480740&amp;ll=21.047128,105.74645&amp;spn=0.011695,0.021136" style="color:#0000FF;text-align:left"  target="_blank" >Xem Bản đồ cỡ lớn hơn</a></small>
		<!-- End Plugin Google Map --> 
	</div>
	 
	<!-- Plugin Facebook -->  
	<iframe src="https://www.facebook.com/plugins/likebox.php?api_key=216628478516704&href=https%3A%2F%2Fwww.facebook.com%2FHocTiengNhatMoiNgay&amp;height=290&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:300px; height:290px;" allowTransparency="true"></iframe>		
	<!-- End Plugin Facebook -->  	
</div>
<div class="clear"></div>