<?php
		include '../model/clsBanner.php';
		include '../dao/BannerDAO.php';

?>
<image src="<?php echo getBannerById(1)->Url ?>" style="display: block; position: fixed; top: 20px; left: 2px; width:150px">
<image src="<?php echo getBannerById(2)->Url ?>" style="display: block; position: fixed; top: 20px; right: 2px; width:150px">
