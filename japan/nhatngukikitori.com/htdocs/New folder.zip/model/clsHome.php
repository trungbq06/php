<?php	
	class clsHome
	{
		public $Id;//string
		public $Content;//
	}
?>