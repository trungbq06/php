<?php	
	class clsLichCLB
	{
		public $Id;//string
		public $Content;//
	}
?>