<?php	
	class clsDescriptionCLBNews
	{
		public $Id;//string
		public $Content;//
		public $IdCLBNews;//string
	}
?>