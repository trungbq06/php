<?php	
	class clsKhoaHoc
	{
		public $Id;//string
		public $Name;//string
	}
?>