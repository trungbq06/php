<?php	
	class clsNews
	{
		public $Id;//string
		public $Title;//
		public $Summary;//string
	}
?>