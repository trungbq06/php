<?php	
	class clsDescriptionNews
	{
		public $Id;//string
		public $Content;//
		public $IdNews;//string
	}
?>