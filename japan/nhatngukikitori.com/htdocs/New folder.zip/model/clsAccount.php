<?php	
	class clsAccount
	{
		public $Id;//string
		public $Username;//
		public $Password;//string
	}
?>