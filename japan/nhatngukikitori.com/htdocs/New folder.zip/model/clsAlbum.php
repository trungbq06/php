<?php	
	class clsAlbum
	{
		public $Id;//string
		public $Title;//
		public $RootImage;//
		public $Content;//
	}
?>