<?php	
	class clsKhaiGiang
	{
		public $Id;//string
		public $StartTime;//string
		public $EndTime; //string
		public $IdKhoaHoc;//string
	}
?>