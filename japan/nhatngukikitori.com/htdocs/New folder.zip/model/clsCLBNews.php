<?php	
	class clsCLBNews
	{
		public $Id;//string
		public $Title;//
		public $Summary;//string
	}
?>