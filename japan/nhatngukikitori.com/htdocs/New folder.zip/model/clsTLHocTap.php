<?php	
	class clsTLHocTap
	{
		public $Id;//string
		public $Title;//
		public $Summary;//string
		public $UrlDownload;//string
	}
?>