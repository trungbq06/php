<?php	
	class clsSlide
	{
		public $Id;//string
		public $Name;//
		public $Url;//string
	}
?>