<?php	
	class clsBanner
	{
		public $Id;//string
		public $Name;//
		public $Url;//string
	}
?>