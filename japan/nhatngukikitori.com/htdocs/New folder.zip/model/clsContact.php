<?php	
	class clsContact
	{
		public $Id;//string
		public $Name;//
		public $Email;//string
		public $Phone;//string
		public $Message;//string
	}
?>