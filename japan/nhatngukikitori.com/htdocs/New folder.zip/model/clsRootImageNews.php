<?php	
	class clsRootImageNews
	{
		public $Id;//string
		public $Url;//
		public $IdNews;//string
	}
?>