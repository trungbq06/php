<?php	
	class clsVideo
	{
		public $Id;//string
		public $Title;//
		public $Url;//string
	}
?>