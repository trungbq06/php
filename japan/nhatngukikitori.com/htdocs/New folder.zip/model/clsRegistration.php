<?php	
	class clsRegistration
	{
		public $Id;//string
		public $Name;//
		public $Phone;//string
		public $Email;//string
		public $Address;//string
		public $IdKhoaHoc;//string
	}
?>