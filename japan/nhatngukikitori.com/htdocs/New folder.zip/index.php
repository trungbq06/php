<?php
Header("Location:pages/Home.php");
?>