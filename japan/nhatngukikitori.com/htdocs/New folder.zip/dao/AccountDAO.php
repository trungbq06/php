<?php
	function createAccount($Username, $Password)
	{
		include 'config.php';
		$sql = "INSERT INTO account(Username, Password) VALUES('" .$Username ."','" .$Password ."')";
		$result = mysql_query($sql,$conn);
		mysql_close($conn);
	}	
	
	function readAccount()
	{
		include 'config.php';			
		$result = mysql_query("SELECT * FROM account",$conn);
		$arr = array();
		while($row = mysql_fetch_array($result))
		{
			$item = new clsAccount();
			$item->Id = $row['Id'];
			$item->Username = $row['Username'];
			$item->Password = $row['Password'];			
			$arr[] = $item;
		}
		mysql_close($conn);	  
		return $arr;
	};
	
	function deleteAccount($Id)
	{
		include 'config.php';
		$sql = "DELETE FROM account WHERE Id=" .$Id ;
		$result = mysql_query($sql,$conn);
		mysql_close($conn);
	}

	function checkAccount($Username, $Password)
	{
		include 'config.php';
		$sql = "SELECT * FROM account WHERE Username='" .$Username."' AND Password='".$Password."'";
		$result = mysql_query($sql);
		$count = mysql_num_rows($result);
		return $count;
		mysql_close($conn);
	}
?>