<?php
		$hostname = 'localhost';
		$username = "root";
		$password = "";
		$database = "japan";
		$conn=mysql_connect($hostname, $username, $password);
		mysql_select_db($database,$conn);
		$result = mysql_query("SET NAMES utf8",$conn);
?>