<?php
class SeparateStickyAndNormal_Listener
{
    public static function templateHook($hookName, &$contents, $params, XenForo_Template_Abstract $template)
    {
		$params = $template->getParams();
		$stickyThreads = count($params['stickyThreads']);
		$visitorLanguage = $params['visitorLanguage'];
		$phrase = $visitorLanguage['phrase_cache'];
		$options = XenForo_Application::get('options');
		if($stickyThreads && $options->ssant_active)
		{
			if($hookName == 'thread_list_threads')
			{
				$contents = '<li class="sectionHeaders">&nbsp;&nbsp;&raquo; ' . $phrase['normal_threads'] . '</li>' . $contents;
			}
			if($hookName == 'thread_list_stickies')
			{
				$contents = '<li class="sectionHeaders">&nbsp;&nbsp;&raquo; ' . $phrase['sticky_threads'] . '</li>' . $contents;
			}
		}
    }
}