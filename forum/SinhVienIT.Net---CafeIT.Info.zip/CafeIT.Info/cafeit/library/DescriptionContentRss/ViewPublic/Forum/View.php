<?php

/**
 * View handling for viewing the details of a specific forum.
 *
 * @package XenForo_Nodes
 */
class DescriptionContentRss_ViewPublic_Forum_View extends XFCP_DescriptionContentRss_ViewPublic_Forum_View
{
	public function renderRss()
	{
		$forum = $this->_params['forum'];
		
		$buggyXmlNamespace = (defined('LIBXML_DOTTED_VERSION') && LIBXML_DOTTED_VERSION == '2.6.24');

		$feed = new Zend_Feed_Writer_Feed();
		$feed->setEncoding('utf-8');
		$feed->setTitle($forum['title']);
		$feed->setDescription($forum['description'] ? $forum['description'] : $forum['title']);
		$feed->setLink(XenForo_Link::buildPublicLink('canonical:forums', $forum));
		if (!$buggyXmlNamespace)
		{
			$feed->setFeedLink(XenForo_Link::buildPublicLink('canonical:forums.rss', $forum), 'rss');
		}
		$feed->setDateModified(XenForo_Application::$time);
		$feed->setLastBuildDate(XenForo_Application::$time);
		if (XenForo_Application::get('options')->boardTitle)
		{
			$feed->setGenerator(XenForo_Application::get('options')->boardTitle);
		}
		
		$threads = $this->_params['threads'];
		
		$firstPostIds = array();
		foreach ($threads AS &$thread)
		{
			$firstPostIds[] = $thread['first_post_id'];
		}
		
		$postModel = XenForo_Model::create('XenForo_Model_Post');
		$posts = $postModel->getPostsByIds($firstPostIds);
		
		$formatter = XenForo_BbCode_Formatter_Base::create();
		$parser = new XenForo_BbCode_Parser($formatter);
		
		foreach ($threads AS $key => $thread)
		{
			$threads[$key]['description'] = '...';
			if (!empty($thread['first_post_id']))
			{
				$content = $posts[$thread['first_post_id']]['message'];
				$content = $parser->render($content);
				
				$threads[$key]['description'] = $content;				
			}
		}		

		foreach ($threads AS $thread)
		{
			$entry = $feed->createEntry();
			$entry->setTitle($thread['title']);
			$entry->setLink(XenForo_Link::buildPublicLink('canonical:threads', $thread));
			$entry->setDescription($thread['description']);
			$entry->setDateCreated(new Zend_Date($thread['post_date'], Zend_Date::TIMESTAMP));
			$entry->setDateModified(new Zend_Date($thread['last_post_date'], Zend_Date::TIMESTAMP));
			if (!$buggyXmlNamespace)
			{
				$entry->addAuthor(array(
					'name' => $thread['username'],
					'uri' => XenForo_Link::buildPublicLink('canonical:members', $thread)
				));
				if ($thread['reply_count'])
				{
					$entry->setCommentCount($thread['reply_count']);
				}
			}

			$feed->addEntry($entry);
		}

		return $feed->export('rss');
	}
}