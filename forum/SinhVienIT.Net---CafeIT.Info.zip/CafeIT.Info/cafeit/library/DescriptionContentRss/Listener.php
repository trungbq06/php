<?php

class DescriptionContentRss_Listener
{
	public static function extendViews($class, array &$extend)
	{
		if ($class == 'XenForo_ViewPublic_Forum_GlobalRss')
		{
			$extend[] = 'DescriptionContentRss_ViewPublic_Forum_GlobalRss';
		}
		
		if ($class == 'XenForo_ViewPublic_Forum_View')
		{
			$extend[] = 'DescriptionContentRss_ViewPublic_Forum_View';
		}
	}
}