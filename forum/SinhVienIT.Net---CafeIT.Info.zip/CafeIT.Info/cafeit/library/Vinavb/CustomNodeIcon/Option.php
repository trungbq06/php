<?php

class Vinavb_CustomNodeIcon_Option {
	const GLOBALS_CONTROLLER_ADMIN_FORUM_ACTION_SAVE = 'Vinavb_XenForo_ControllerAdmin_Forum::actionSave';
	const GLOBALS_CONTROLLER_ADMIN_PAGE_ACTION_SAVE = 'Vinavb_XenForo_ControllerAdmin_Page::actionSave';

	const KEY_NODE_ICONS = 'Vinavb_CustomNodeIcon_icons';

	const KEY_PARAMS_NODE = 'Vinavb_CustomNodeIcon_node';

	const FORM_ICON_FIRST = 'vinavb_customnodeicon_first';
	const FORM_ICON_SECOND = 'vinavb_customnodeicon_second';
}