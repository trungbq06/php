<?php

$config['db']['host'] = 'localhost';
$config['db']['port'] = '3306';
$config['db']['username'] = 'root';
$config['db']['password'] = 'admin';
$config['db']['dbname'] = 'cafeit';


$config['superAdmins'] = '1';