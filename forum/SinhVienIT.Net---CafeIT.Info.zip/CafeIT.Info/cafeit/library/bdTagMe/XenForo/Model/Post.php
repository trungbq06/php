<?php

class bdTagMe_XenForo_Model_Post extends XFCP_bdTagMe_XenForo_Model_Post
{
	public function alertTaggedMembers(array $post, array $thread, array $forum, array $tagged, array $alreadyAlerted)
	{
		return array();
	}
}
