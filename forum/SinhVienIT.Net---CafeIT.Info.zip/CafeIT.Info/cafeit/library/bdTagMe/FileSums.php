<?php

class bdTagMe_FileSums
{
	public static function getHashes()
	{
		return array (
  'library/bdTagMe/XenForo/Route/Prefix/Members.php' => 'ca64b4d980a788365bae15a0151a8fbf',
  'library/bdTagMe/XenForo/Model/User.php' => 'c175fc3297dfd0c2a5048f12594e99da',
  'library/bdTagMe/XenForo/Model/ProfilePost.php' => '9b67139f49ab2cda56bcb23187d29451',
  'library/bdTagMe/XenForo/Model/Post.php' => '79fce10a78bcadf15b7d3e7b293d1c0e',
  'library/bdTagMe/XenForo/Model/ForumWatch.php' => '3d1b1f7149d09c138dcd4515fdc0f588',
  'library/bdTagMe/XenForo/Model/UserTagging.php' => '510ddc7c0422634a3db34bb9c4670977',
  'library/bdTagMe/XenForo/Model/Alert.php' => 'ee700c23092e28c3c2abef62cde7906c',
  'library/bdTagMe/XenForo/BbCode/Formatter/HtmlEmail.php' => 'b3aabfda1ef5cb9cdc903ede07df0c4a',
  'library/bdTagMe/XenForo/BbCode/Formatter/Text.php' => '1ed2f2802959651d5435c780d565e03b',
  'library/bdTagMe/XenForo/BbCode/Formatter/Base.php' => '3e2a9335bcbde94a815dcc8dd3ce437f',
  'library/bdTagMe/XenForo/DataWriter/DiscussionMessage/ProfilePost.php' => 'c10f369d224c996571492fa3c0f566be',
  'library/bdTagMe/XenForo/DataWriter/DiscussionMessage/Post.php' => '7b798c9281f12ccf49afca8d3c8b3670',
  'library/bdTagMe/XenForo/DataWriter/UserGroup.php' => '97307bf1ae1415e35cde19fdb2e9d25a',
  'library/bdTagMe/XenForo/DataWriter/User.php' => '8e88f81ed5a56afd1538af829b729179',
  'library/bdTagMe/XenForo/DataWriter/ProfilePostComment.php' => '64591c9bc3f6b43a750f31166fb79265',
  'library/bdTagMe/XenForo/ControllerAdmin/UserGroup.php' => 'dc33fd00371a08b8b4d78bdfdd4a26a7',
  'library/bdTagMe/XenForo/ControllerPublic/Account.php' => '228f5032336fa06a4b1c6cf21d00f01c',
  'library/bdTagMe/XenForo/ControllerPublic/Member.php' => 'f38a6196ef725c90872712e401ede90c',
  'library/bdTagMe/bdAlerts/Model/Mail.php' => '10485e6bcc23a103cd31783b198b47b2',
  'library/bdTagMe/Option.php' => 'b5ad7572de36fa23754ddb2bfdaead1f',
  'library/bdTagMe/Installer.php' => '58139b65668886ec0173dd9e4f50390b',
  'library/bdTagMe/Listener.php' => 'a4bfc03577f7759abd62d188d3a51fbc',
  'library/bdTagMe/Engine.php' => '6b4c227ff61aec6b1aa41369164b1753',
  'js/bdTagMe/full/frontend.js' => '8f5aa758b3eab2070e6dd5837b17ac3d',
  'js/bdTagMe/full/tinymce_plugin.js' => 'b0d46a2ceddc71d243f9fee2baddc463',
  'js/bdTagMe/frontend.js' => '9352251c294306be778fe467538d17f8',
  'js/bdTagMe/tinymce_plugin.js' => '330e3bff9acdbe429966e643510dbc6b',
);
	}
}